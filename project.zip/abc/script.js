function login(){
  window.location.href = "https://www.tutorialrepublic.com/";
}